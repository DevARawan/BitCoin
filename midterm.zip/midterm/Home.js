import React from 'react';
import { View, Text, FlatList } from 'react-native';
import useBitcoinData from './customhook';

const Home = () => {
  const bitcoinData = useBitcoinData();

  return (
    <View style={{justifyContent: 'center', alignItems: 'center'}}>
      <Text>Bitcoin Price is</Text>
      {bitcoinData && (
        <FlatList
          data={Object.entries(bitcoinData.bpi)}
          keyExtractor={(item) => item[0]}
          renderItem={({ item }) => (
            <Text>{ `${item[1].description}: ${item[1].rate}`}</Text>
          )}
        />
      )}
    </View>
  );
};

export default Home;