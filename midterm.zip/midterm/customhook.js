import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const useBitcoinData = () => {
  const [bitcoinData, setBitcoinData] = useState(null);

  useEffect(() => {
    const fetchDataAndSaveToStorage = async () => {
      try {
        // First, try to fetch data from AsyncStorage
        const storedData = await AsyncStorage.getItem('bitcoinData');

        if (storedData) {
          // If data is found in AsyncStorage, use it
          setBitcoinData(JSON.parse(storedData));
        } else {
          // If data is not in AsyncStorage, fetch it from the API
          const response = await fetch('https://api.coindesk.com/v1/bpi/currentprice.json');
          const data = await response.json();

          // Save the fetched data to AsyncStorage
          await AsyncStorage.setItem('bitcoinData', JSON.stringify(data));

          setBitcoinData(data);
        }
      } catch (error) {
        console.error('Error fetching or saving Bitcoin data:', error);
    }
  };

  fetchDataAndSaveToStorage();
}, []);

return bitcoinData;
};

export default useBitcoinData;
